// ضع رابط API الخلفي الخاص بالبوت هنا بعد نشره على استضافة تدعم Node.js وHTTPS.
window.QHT_CONFIG = {
  API_BASE: "https://api.example.com"
};
