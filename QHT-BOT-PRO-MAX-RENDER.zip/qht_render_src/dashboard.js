(() => {
  const API = (window.QHT_CONFIG?.API_BASE || "").replace(/\/$/, "");
  const $ = id => document.getElementById(id);
  const state = { guilds: [], guildId: "", data: null };
  const loginCard = $("login-card"), app = $("app"), settingsPanel = $("settings-panel"), notice = $("notice");
  const api = async (path, options = {}) => {
    const response = await fetch(`${API}${path}`, { credentials: "include", ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
    const data = await response.json().catch(() => ({}));
    if (response.status === 401) throw new Error("سجل دخولك من جديد عبر Discord.");
    if (!response.ok) throw new Error(data.error || "تعذر تنفيذ الطلب.");
    return data;
  };
  function message(text, error = false) { notice.textContent = text; notice.classList.remove("hidden", "error"); if (error) notice.classList.add("error"); }
  function fillSelect(id, items, selected, emptyLabel) {
    const select = $(id); select.innerHTML = "";
    const empty = document.createElement("option"); empty.value = ""; empty.textContent = emptyLabel; select.append(empty);
    for (const item of items) { const option = document.createElement("option"); option.value = item.id; option.textContent = item.name; select.append(option); }
    select.value = selected || "";
  }
  async function init() {
    if (!API || API.includes("example.com")) { message("ضع رابط API الحقيقي في ملف config.js بعد تشغيل API البوت.", true); loginCard.classList.remove("hidden"); return; }
    $("login").href = `${API}/auth/login`;
    try {
      const me = await api("/api/me");
      $("user-name").textContent = me.user.global_name || me.user.username;
      $("logout").classList.remove("hidden"); loginCard.classList.add("hidden"); app.classList.remove("hidden");
      const result = await api("/api/guilds"); state.guilds = result.guilds;
      const select = $("guild-select");
      select.innerHTML = '<option value="">اختر السيرفر</option>';
      state.guilds.forEach(g => { const o = document.createElement("option"); o.value = g.id; o.textContent = g.name; select.append(o); });
      if (!state.guilds.length) message("لم نجد سيرفرًا تملك فيه صلاحية الإدارة والبوت موجود فيه.", true);
    } catch (error) {
      loginCard.classList.remove("hidden"); app.classList.add("hidden");
      if (!location.search.includes("login=failed")) message(error.message, true);
      else message("تعذر تسجيل الدخول. تحقق من إعدادات OAuth2.", true);
    }
  }
  async function loadGuild(id) {
    state.guildId = id; settingsPanel.classList.add("hidden"); if (!id) return;
    try {
      const data = await api(`/api/guild/${id}/config`); state.data = data;
      fillSelect("welcome", data.textChannels, data.config.welcome, "بدون تحديد");
      fillSelect("category", data.categories, data.config.category, "بدون تحديد");
      fillSelect("alert-channel", data.textChannels, data.security.alert_channel, "بدون تحديد");
      $("sec-enabled").checked = !!data.security.enabled;
      $("raid").value = data.security.raid_threshold; $("nuke").value = data.security.nuke_threshold;
      $("spam").value = data.security.spam_threshold; $("mentions").value = data.security.mention_limit;
      settingsPanel.classList.remove("hidden"); notice.classList.add("hidden");
    } catch (error) { message(error.message, true); }
  }
  async function save(payload, success) {
    if (!state.guildId) return message("اختر سيرفرًا أولاً.", true);
    try { const result = await api(`/api/guild/${state.guildId}/config`, { method: "PUT", body: JSON.stringify(payload) }); message(result.message || success); }
    catch (error) { message(error.message, true); }
  }
  $("guild-select").addEventListener("change", e => loadGuild(e.target.value));
  $("save-general").addEventListener("click", () => save({ welcome: $("welcome").value, category: $("category").value }, "تم حفظ الإعدادات العامة."));
  $("save-security").addEventListener("click", () => save({ enabled: $("sec-enabled").checked, alert_channel: $("alert-channel").value, raid_threshold: Number($("raid").value), nuke_threshold: Number($("nuke").value), spam_threshold: Number($("spam").value), mention_limit: Number($("mentions").value) }, "تم حفظ إعدادات الحماية."));
  $("logout").addEventListener("click", async () => { try { await api("/auth/logout", { method: "POST", body: "{}" }); } finally { location.href = "/"; } });
  init();
})();
