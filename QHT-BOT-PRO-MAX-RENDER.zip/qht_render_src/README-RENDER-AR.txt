QHT BOT PRO MAX - نسخة الموقع لـ Render

محتويات هذه النسخة:
- الموقع الرئيسي.
- صفحة لوحة التحكم.
- خادم Node.js صغير لتشغيل ملفات الموقع على Render.
- مسار /health لفحص الخدمة.
- config.js ديناميكي يقرأ رابط API من متغير QHT_API_BASE.

طريقة النشر:
1) ارفع محتويات هذا المجلد إلى مستودع GitHub جديد.
2) في Render اختر New + ثم Blueprint أو Web Service واربط مستودع GitHub.
3) إذا استخدمت Blueprint سيقرأ render.yaml تلقائياً.
4) بعد النشر افتح Environment في Render وأضف:
   QHT_API_BASE = رابط API العام الذي يعمل عبر HTTPS
5) احفظ التغيير وأعد النشر.

مهم:
هذه الحزمة تستضيف واجهة الموقع فقط. لوحة التحكم تحتاج API الخاص بالبوت حتى تعمل.
ملف src/dashboard.js الموجود في مشروع البوت يعتمد على كائن Discord client وقاعدة بيانات البوت، لذلك يجب أن يبقى API مشغلاً مع البوت على استضافته الحالية أو يتم نقل البوت نفسه مع قاعدة بياناته. لا تضع DISCORD_TOKEN أو DISCORD_CLIENT_SECRET داخل ملفات الموقع أو GitHub.

إعدادات OAuth2 في Discord Developer Portal يجب أن تتضمن Redirect URL:
https://رابط-api-العام/auth/callback

بعد نشر الواجهة، ضع رابط الموقع النهائي ضمن DASHBOARD_FRONTEND_URL في بيئة تشغيل البوت، ورابط API العام ضمن DASHBOARD_PUBLIC_URL، واضبط QHT_API_BASE في Render على نفس رابط API.
